#This will be used to use only a single copy of API Key and use this file
# as a module and import it to other .py files

API_URL = "<Your_API_URL>" 
API_KEY = "<Your_API_KEY>" 
SECRET_KEY = "<Your_Secret_Key>"

DB_FILE = 'T:\Python TA\Full stack trading app\data.db'

#Discord WEBHOOK
WEBHOOK_URL = "<Your_Discord_WEBHOOK_URL>"