# Modules***********************************************XX
from os import close
import ccxt, csv
import pandas_ta as ta
import pandas as pd
import requests, config

def ta_ema (x,y):
    tickers = x
    tf = y
    #Code Start*********************************************XX
    exchange = ccxt.binanceusdm()
    bars = exchange.fetch_ohlcv(tickers , timeframe = tf , limit = 300)
    df = pd.DataFrame(bars,columns=['time','open','high','low','close','volume'])
    df['time']=pd.to_datetime(df['time'], unit='ms')
    #df counter---------------------------**
    counter = [*range(0,300)]

    # EMAs Are coded here:**********************************XX
    ema8 = df.ta.ema(8)
    ema14 = df.ta.ema(14)
    ema50 = df.ta.ema(50)
    ema200 = df.ta.ema(200)
    EMA = pd.concat([ema8, ema14, ema50, ema200], axis =1)
    #ADX is coded here--------------------**
    adx= df.ta.adx()
    adx_req = pd.DataFrame(adx['ADX_14'])
    int_a = int(adx_req.iloc[-3])
    int_b = int(adx_req.iloc[-4])
    int_c = int(adx_req.iloc[-5])
    adx_avg = (int_a + int_b + int_c)/3

    #Semi Final DF is here:**************************************XX(Producing one single df of all the OHLC+ADX+EMAs)
    df = pd.concat([df,adx, EMA],axis =1)

    #RANGE Defining:****************************************XX
    #Upper-Limit----------------------------**(defining the upper limit of the area/range around the EMA 200)
    uplimit = []
    n=0
    for n in counter:
        sum=(float((0.001*(df['EMA_200'][n]))) + float (df['EMA_200'][n]))
        uplimit.append (sum)

    up_limit = pd.DataFrame(uplimit, columns=['up_rnge'])

    #Lower-limit----------------------------** (defining the lower limit of the area/range around the EMA 200)
    lowlimit = []
    n=0
    for n in counter:
        minus=(float((df['EMA_200'][n])) - float ((0.001*(df['EMA_200'][n]))))
        lowlimit.append (minus)

    low_limit = pd.DataFrame(lowlimit, columns=['low_rnge'])

    #CONCAT Interest RANGE:-----------------** (Producing a DF of both the limit and defining the RANGE )
    rnge = pd.concat([up_limit,low_limit], axis=1)


    #Final DF is here:**************************************XX (Producing one single df of all the OHLC+ADX+EMAs+Interest-Range)
    df = pd.concat([df,rnge],axis =1)

    last_row = df.iloc[-2]#Reason for taking last second row.
    """It starts storing values in the new row, the second that a candle starts
    Kyuki Live data lena shuru krdeta hai, agar 9;15 ko execute karunga toh
    9:15 ke live moving candle ke data pe result dikhayega after a minute of executing rather than
    showing one minute previous data and alerting on that basis"""
    print(last_row)
    isSentMessage = False

    #Alert Trigger Logic:*********************************XX
    if (last_row['low'] < last_row['up_rnge']) and (last_row['high'] > last_row['low_rnge']):
        message = "**Price is near the 200 EMA**, TimeFrame: {}\nOpen: ${},\nClose: ${},\n200-EMA: ${},\n**ADX:** {}" .format((tf),(last_row['open']),(last_row['close']),(last_row['EMA_200']),(last_row['ADX_14']))
        print(message)
        payload = {
        "username": ("EMA (Alertbot) {}-PERP {}".format(tickers,tf)),
        "content": message
        }
        requests.post(config.WEBHOOK_URL, json=payload)
        isSentMessage = True

    if (isSentMessage == False) and (last_row['low'] < last_row['up_rnge']) and (last_row['high'] > last_row['low_rnge']):
        message = "**Price is near the 200 EMA**, TimeFrame: {}\nOpen: ${},\nClose: ${},\n200-EMA: ${},\n**ADX:** {}" .format((tf),(last_row['open']),(last_row['close']),(last_row['EMA_200']),(last_row['ADX_14']))
        print(message)
        payload = {
        "username": ("EMA (Alertbot) {}-PERP {}".format(tickers,tf)),
        "content": message
        }
        requests.post(config.WEBHOOK_URL, json=payload)


#List of Ticker Symbols

ticker_sym=pd.read_csv('ticker.csv', header=None)
ticker_sym.columns=['symbol']

timeframe = ['30m','1h','2h','4h']

#Execution of Code along with Data.
def run_final(x):
    z=0
    lent = len(timeframe)
    lens = len(ticker_sym)
    w=""
    t=""

    while z < lent: 
        t=str(timeframe[z])
        print(t)
        c=0
        while c< lens:
            w=(ticker_sym['symbol'][c])
            print(w)
            ta_ema(w,t)
            c=c+1
        z=z+1

# END of the Code------------------------------------------------------
dummy =0 
run_final(dummy)