This is a very basic Discord Alert bot script.

Which helps in scanning the crypto markets for people who find it difficult to scan several market symbols.
The user can add more ticker symbols in the 'ticker.csv' file. There are a few that I have used for testing the Alert Bot.

In order to customize this script for one's benefit, He/She should be adding the WEBHOOK_URL from their discord channel in 
the 'config.py' File and also can add or remove the ticker symbols he/she needs as per their own requirements.

Also they can go ahead and add more timeframes in the 
line 96 of the code. *NOTE that the format must be kept the same while editing the line in the file.

 